data:extend({
  {
    type = "shortcut",
    name = "fbp-toggle",
    order = "a",
    action = "lua",
    toggleable = true,
    icon = "__Factorio_Blueprint_Printer__/graphics/icons/icon_placement.png",
    icon_size = 64,
    icon_mipmaps = 4,
    small_icon = "__Factorio_Blueprint_Printer__/graphics/icons/icon_placement.png",
    small_icon_size = 64,
    small_icon_mipmaps = 4
  },
  {
    type = "custom-input",
    name = "fbp-open-config",
    key_sequence = "SHIFT + mouse-button-1",
    action = "lua"
  }
})
