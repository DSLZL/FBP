data:extend({
  {
    type = "int-setting",
    name = "fbp-speed",
    setting_type = "runtime-per-user",
    default_value = 30,
    minimum_value = 1,
    maximum_value = 600,
    order = "a"
  },
  {
    type = "int-setting",
    name = "fbp-scan-radius",
    setting_type = "runtime-per-user",
    default_value = 100,
    minimum_value = 10,
    maximum_value = 500,
    order = "a-a"
  },
  {
    type = "bool-setting",
    name = "fbp-batch-mode",
    setting_type = "runtime-per-user",
    default_value = true,
    order = "a-b"
  },
  {
    type = "bool-setting",
    name = "fbp-enable-for-me",
    setting_type = "runtime-per-user",
    default_value = true,
    order = "a-a"
  },
  {
    type = "bool-setting",
    name = "fbp-allow-others",
    setting_type = "runtime-global",
    default_value = false,
    order = "c"
  },
  {
    type = "string-setting",
    name = "fbp-debug-mode",
    setting_type = "runtime-per-user",
    default_value = "none",
    allowed_values = {"none", "personal", "all"},
    order = "d"
  }
})
